import classes.*;
import java.lang.*;

public class Start
{
	public static void main(String[] args)
	{
		new FrontPage();
	}
}