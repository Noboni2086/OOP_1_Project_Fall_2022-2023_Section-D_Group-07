package classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import static javax.swing.JOptionPane.showMessageDialog;
import java.io.*;
import java.nio.file.*;
import java.util.*;


 public class AdminDashboard 
{
	
	JFrame frame;
	JPanel backpanel;
	JPanel intropanel;
	JButton textB;
	JLabel text;
	JButton storyB;
	JLabel story;
	JButton comicB;
	JLabel comic;
	JButton childB;
	JLabel child;
	JLabel intro;
	JTextField search;
	JButton searchB;
	JButton adminB;
	JLabel admin;
	JButton exitB;
	JButton minB;
	JButton backB;
	JLabel adding;
	
	AdminDashboard ()
	{
		frame = new JFrame();
	    frame.setLayout(null);
		
	    frame.setSize(1300,700);
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//font
		Font f1 = new Font("Harlow Solid Italic", Font.PLAIN, 20);
		Font f2 = new Font("Freestyle Script", Font.BOLD, 38);
		Font f3 = new Font("Times New Roman", Font.BOLD, 24);
		Font f4 = new Font("Times New Roman", Font.PLAIN, 18);
		Font f5 = new Font("Times New Roman", Font.PLAIN, 16);
		
		//background panel
		JPanel backpanel = new JPanel();
	    backpanel.setBackground(new Color(192,192,192));
	    backpanel.setBounds(0,0,1300,700);
	    backpanel.setVisible(true);
	    backpanel.setLayout(null);
		frame.add(backpanel);
		
		adding = new JLabel("click here to add booklists");
		adding.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				new BookInfo();
        		frame.setVisible(false);
			}
		});
		adding.setForeground(new Color(128, 128, 0));
		adding.setBounds(100, 250, 270, 25);
		adding.setFont(f1);
		backpanel.add(adding);
		
		
		//adding categories
		//textbook
		textB = new JButton();
        textB.setIcon(new ImageIcon("./photos/text.png"));
        textB.setBounds(70,400,250,170);
		textB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				new TextBook();
        		frame.setVisible(false);
			}
		});
		textB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backpanel.add(textB);
		
		text = new JLabel("textbook");
		text.setForeground(new Color(0,0,0));
		text.setBounds(160, 580, 170, 25);
		text.setFont(f1);
		backpanel.add(text);
		
		//storybook
		storyB = new JButton();
        storyB.setIcon(new ImageIcon("./photos/story.jpg"));
        storyB.setBounds(370,400,250,170);
		storyB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				new StoryBook();
        		frame.setVisible(false);
			}
		});
		storyB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backpanel.add(storyB);
		
		story = new JLabel("storybook");
		story.setForeground(new Color(0,0,0));
		story.setBounds(460, 580, 170, 25);
		story.setFont(f1);
		backpanel.add(story);
		
		
		//comicbook
		comicB = new JButton();
        comicB.setIcon(new ImageIcon("./photos/comic.jpg"));
        comicB.setBounds(670,400,250,170);
		comicB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				showMessageDialog(null, "Not available","Warning", JOptionPane.WARNING_MESSAGE);
        		//frame.setVisible(false);
			}
		});
		comicB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backpanel.add(comicB);
		
		comic = new JLabel("comicbook");
		comic.setForeground(new Color(0,0,0));
		comic.setBounds(760, 580, 170, 25);
		comic.setFont(f1);
		backpanel.add(comic);
		
		//childrenbook
		childB = new JButton();
        childB.setIcon(new ImageIcon("./photos/child.png"));
        childB.setBounds(970,400,250,170);
		childB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				showMessageDialog(null, "Not available","Warning", JOptionPane.WARNING_MESSAGE);
        		//frame.setVisible(false);
			}
		});
		childB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backpanel.add(childB);
		
		child = new JLabel("comicbook");
		child.setForeground(new Color(0,0,0));
		child.setBounds(1060, 580, 170, 25);
		child.setFont(f1);
		backpanel.add(child);
		
        
		//intro panel
        intropanel = new JPanel();
	    intropanel.setBackground(new Color(255,255,255));
	    intropanel.setBounds(0,0,1300,120);
	    intropanel.setVisible(true);
	    intropanel.setLayout(null);
		backpanel.add(intropanel);
		
		//title labels
		intro = new JLabel("FLEUR online Bookshop");
		intro.setForeground(new Color(212,175,55));
		intro.setBounds(515, 20, 400, 30);
		intro.setFont(f2);
		intropanel.add(intro);
		
		//intro labels
		intro = new JLabel("Get your favourite books right now!");
		intro.setForeground(Color.BLACK);
		intro.setBounds(505, 60, 400, 30);
		intro.setFont(f1);
		intropanel.add(intro);
		
		//creating search field
		search = new JTextField("search");
		search.setBackground(new Color(192,192,192));
		search.setBounds(100, 30, 250, 30);
		intropanel.add(search);
		
		//searchbutton
		searchB = new JButton();
        searchB.setIcon(new ImageIcon("./photos/searchicon.png"));
		searchB.setBackground(new Color(192,192,192));
        searchB.setBounds(355,30,30,30);
		searchB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				String name = search.getText();
				boolean nEmpty = name.isEmpty();
				String n = "Name :"+name;
				
				if(nEmpty==true)
				{
					showMessageDialog(null, "please enter book name","Warning", JOptionPane.WARNING_MESSAGE);
				}
				
				else
				{
					boolean bname = false;
					try
					{
						FileReader fr = new FileReader(".\\File\\booklist.txt");
						BufferedReader fbr = new BufferedReader(fr);
						
						int allLine = 0;
						while(fbr.readLine()!=null)
						{
							allLine++;
						}
						fbr.close();
						
						for(int i=0; i<allLine; i++)
						{
							String line = Files.readAllLines(Paths.get(".\\File\\booklist.txt")).get(i);
							
							if(line.equals(n))
							{
								if(n.equals("Name :Harry Potter & the Prisoner of Azkaban"))
								{
									bname = true;
								    new Storybook1();
								    frame.setVisible(false);
								    break;
								}
								
								else if(n.equals("Name :The Hobbit"))
								{
									bname = true;
								    new Storybook2();
								    frame.setVisible(false);
								    break;
								}
								
								else if(n.equals("Name :A Study in Scarlet"))
								{
									bname = true;
								    new Storybook3();
								    frame.setVisible(false);
								    break;
								}
								
								else if(n.equals("Name :The Haunting Of The Hill House"))
								{
									bname = true;
								    new Storybook4();
								    frame.setVisible(false);
								    break;
								}
								
								else if(n.equals("Name :Java: The Complete Reference"))
								{
									bname = true;
								    new Textbook1();
								    frame.setVisible(false);
								   break;
								}
								
								else if(n.equals("Name :Discrete Mathematics and Its Applications"))
								{
									bname = true;
								    new Textbook2();
								    frame.setVisible(false);
								   break;
								}
								
								else if(n.equals("Name :Calculus"))
								{
									bname = true;
								    new Textbook3();
								    frame.setVisible(false);
								   break;
								}
								
								else if(n.equals("Name :Fundamentals of Physics"))
								{
									bname = true;
								    new Textbook4();
								    frame.setVisible(false);
								   break;
								}
									
								else
								{
									bname = false;
									showMessageDialog(null, "Not available","Warning", JOptionPane.WARNING_MESSAGE);
								}
								
							}
							
							else
							{
								bname = false;
								//showMessageDialog(null, "Not available","Warning", JOptionPane.WARNING_MESSAGE);
								
							}
						}
						
						if(bname==false)
						{
							showMessageDialog(null, "Not available","Warning", JOptionPane.WARNING_MESSAGE);
						}
					}
					
					catch(Exception ei)
					{
						System.out.println(ei);
					}
					
				}
			}
		});
		
		searchB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		intropanel.add(searchB);
		
		
		//accountbutton
		adminB = new JButton();
        adminB.setIcon(new ImageIcon("./photos/account.png"));
		adminB.setBackground(new Color(255,255,255));
        adminB.setBounds(1100,20,55,55);
		adminB.setFocusPainted(false);
        adminB.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        adminB.setContentAreaFilled(false);
		intropanel.add(adminB);
		
		//adminname
		admin = new JLabel("admin");
		admin.setForeground(Color.BLACK);
		admin.setBounds(1108, 77, 55, 16);
		admin.setFont(f5);
		intropanel.add(admin);
		
		//exit button
		exitB = new JButton();
		
		exitB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				  frame.setVisible(false);
			}
		});
		exitB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		exitB.setIcon(new ImageIcon("./photos/exit.png"));
		exitB.setBackground(new Color(255,255,255));
        exitB.setBounds(1230, 2, 25, 25);
        exitB.setFocusPainted(false);
        exitB.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        exitB.setContentAreaFilled(false);
		intropanel.add(exitB);

        //minimize button
        minB = new JButton();
		
		minB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				   frame.setState(Frame.ICONIFIED);
			}
		});
		minB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		minB.setIcon(new ImageIcon("./photos/min.png"));
		minB.setBackground(new Color(0,0,0));
        minB.setBounds(1190, 2, 24, 24);
        minB.setFocusPainted(false);
        minB.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        minB.setContentAreaFilled(false);
		intropanel.add(minB);
		
		//back button
		backB = new JButton();
		
		backB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				new Admin();
        		frame.setVisible(false);
			}
		});
		backB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
        backB.setIcon(new ImageIcon("./photos/back.png"));
		backB.setBackground(new Color(255,255,255));
        backB.setBounds(10, 2, 25, 25);
        backB.setFocusPainted(false);
        backB.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        backB.setContentAreaFilled(false);
		intropanel.add(backB);
		
		/*//sign out
		bl4 = new JButton("Sign Out");
        bl4.setBounds(1260, 50, 90, 25);
        bl4.setFont(new Font("Segoe UI", Font.BOLD, 16));
        bl4.setCursor(new Cursor(Cursor.HAND_CURSOR));
        bl4.setFocusPainted(false);
        bl4.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        bl4.setCursor(new Cursor(Cursor.HAND_CURSOR));
        bl4.setContentAreaFilled(false);*/
		
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
		frame.setResizable(false);
	
	}
	
	
	public static void main (String [] args ){
		
		new AdminDashboard();	
	}	
}