package classes;
import javax.swing.*;
import java.awt.*;
import java.awt.Font;
import java.awt.event.*;
import java.awt.Color;
import java.util.*;
import java.awt.Cursor;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import static javax.swing.JOptionPane.showMessageDialog;


public class Textbook4{
	
	   
	      boolean c = false;
		JLabel J_Welcome,J_favourite,J_name,J_Edition,J_Author,Isbn,J_Publisher,Order,J_Standard,J_Category,J_Taka,Buy,Quantity,total,User_amount;
		JButton Cart,B,Add_To_Cart;
		JButton exitB, minB, backB;
		int result=0;
		String S ;



	public Textbook4()
	{
		
	JFrame  frame = new JFrame();	 
    frame.setIconImage(Toolkit.getDefaultToolkit().getImage("Untitled.png"));
    frame.setLayout(null);
    frame.setSize(1100, 700);//(X,Y)
	
	//exit button
		exitB = new JButton();
		
		exitB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				  frame.setVisible(false);
			}
		});
		exitB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		exitB.setIcon(new ImageIcon("./photos/exit.png"));
		exitB.setBackground(new Color(255,255,255));
        exitB.setBounds(1005, 20, 25, 25);
        exitB.setFocusPainted(false);
        exitB.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        exitB.setContentAreaFilled(false);
		frame.add(exitB);

        //minimize button
        minB = new JButton();
		
		minB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				   frame.setState(Frame.ICONIFIED);
			}
		});
		minB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		minB.setIcon(new ImageIcon("./photos/min.png"));
		minB.setBackground(new Color(0,0,0));
        minB.setBounds(955, 20, 24, 24);
        minB.setFocusPainted(false);
        minB.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        minB.setContentAreaFilled(false);
		frame.add(minB);
		
		//back button
		backB = new JButton();
		
		backB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				new TextBook();
        		frame.setVisible(false);
			}
		});
		backB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
        backB.setIcon(new ImageIcon("./photos/back.png"));
		backB.setBackground(new Color(255,255,255));
        backB.setBounds(40, 20, 25, 25);
        backB.setFocusPainted(false);
        backB.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        backB.setContentAreaFilled(false);
		frame.add(backB);

    Font f1 =new Font ( "Freestyle Script",Font.BOLD,50);
    Font f2 =new Font ( "Harlow Solid Italic",Font.PLAIN,24);
    Font f3 =new Font ( "Times New Roman",Font.BOLD,30);
	  Font f4 =new Font ( "Times New Roman",Font.PLAIN,20);
	
     JLabel J_Welcome = new JLabel( "Welcome to Fleur Bookshop");
	   J_Welcome.setForeground(Color.black);
	    J_Welcome.setForeground(new Color(212,175,55));
        J_Welcome.setBounds(320, 0, 800, 80);
        J_Welcome.setFont(f1);
        frame.add(J_Welcome);


     J_favourite = new JLabel( "get your favourite books right now!");
	    J_favourite.setForeground(Color.black);
	    J_favourite.setForeground(new Color(0,5,0));
        J_favourite.setBounds(350, 30, 770, 90);
		
        J_favourite.setFont(f2);

        frame.add(J_favourite);




     J_name = new JLabel( "Fundamentals of Physics");
	    J_name.setForeground(Color.black);
	    J_name.setForeground(new Color(0,5,0));
        J_name.setBounds(390, 99, 750, 80);
		
        J_name.setFont(f3);

        frame.add(J_name);


    J_Edition = new JLabel( "("+"Tenth Edition"+")");
	    J_Edition.setForeground(Color.black);
	    J_Edition.setForeground(new Color(0,5,0));
        J_Edition.setBounds(390, 125, 750, 80);
		
        J_Edition.setFont(f4);

        frame.add(J_Edition);
		
		
	 J_Author = new JLabel( "Author   : Halliday & Resnick" );
	    J_Author.setForeground(Color.black);
	    J_Author.setForeground(new Color(0,5,0));
        J_Author.setBounds(390, 170, 750, 80);
		
        J_Author.setFont(f4);

        frame.add(J_Author);
		
		
		
		
			
	    JLabel Isbn = new JLabel( "ISBN     : 978-1118230718" );
	    Isbn.setForeground(Color.black);
	    Isbn.setForeground(new Color(0,5,0));
        Isbn.setBounds(390, 200, 750, 80);
        Isbn.setFont(f4);
        frame.add(Isbn);
		
		
	
	JLabel J_Publisher = new JLabel( ( "Publisher: Wiley"+"("+"2015"+")" ) );
	    J_Publisher.setForeground(Color.black);
	    J_Publisher.setForeground(new Color(0,5,0));
        J_Publisher.setBounds(390, 230, 850, 80);
        J_Publisher.setFont(f4);
        frame.add(J_Publisher);
		
		

	J_Standard = new JLabel("Standard: 15");
	    J_Standard.setForeground(Color.black);
	    J_Standard.setForeground(new Color(0,5,0));
        J_Standard.setBounds(390, 260, 850, 80);
        J_Standard.setFont(f4);
        frame.add(J_Standard);
		
		
	 J_Taka = new JLabel( "Taka : 1950");
	    J_Taka.setForeground(Color.black);
	    J_Taka.setForeground(new Color(0,5,0));
        J_Taka.setBounds(390, 290, 850, 80);
        J_Taka.setFont(f3);
        frame.add(J_Taka);


	
	JLabel Buy = new JLabel( "In Stock " );
	    Buy.setForeground(Color.black);
	    Buy.setForeground(new Color(255, 0, 0));
        Buy.setBounds(390, 320, 850, 80);
		
        Buy.setFont(f4);

        frame.add(Buy);


    Order = new JLabel( "* Order before stock out *" );
	    Order.setForeground(Color.black);
	    Order.setForeground(new Color(5, 102, 8));
        Order.setBounds(390, 350, 850, 80);
		
        Order.setFont(f4);

        frame.add(Order);


     Quantity = new JLabel( "Quantity" );
	    Quantity.setForeground(Color.black);
	    Quantity.setForeground(new Color(5, 0, 0));
        Quantity.setBounds(390, 380, 850, 80);
		
        Quantity.setFont(f4);

        frame.add(Quantity);
		
	User_amount= new JLabel( "000.0");
	    User_amount.setForeground(Color.black);
	    User_amount.setForeground(new Color(5, 0, 0));
        User_amount.setBounds(520, 440, 200, 20);
        User_amount.setFont(f4);
        frame.add(User_amount);
		
		
	
     total = new JLabel( "Total Amount :" );
	    total.setForeground(Color.black);
	    total.setForeground(new Color(5, 0, 0));
        total.setBounds(390, 440, 171, 20);
		total.setOpaque(false);
        total.setFont(f4);
        frame.add(total);
			
	//jcombobox
    String quantity[] = { "1", "2", "3", "4", "5", "6", "7"};
       JComboBox cb1 =new  JComboBox(quantity);
       cb1.setBounds(460, 410, 80, 20);
       frame.add(cb1);

  //action lisener on combo box
		 cb1 .addActionListener(new ActionListener()

        {
           public void actionPerformed(ActionEvent e)

            {
	
	String n;
	double k;

                    n =(String) cb1.getSelectedItem();//String n
					 result=Integer.parseInt(n);
				     k =1950*result;//double k
					 S = String.valueOf(k);//String s
					 System.out.println(S);
					 User_amount.setText(S);
					 	
					  
                }
        }  );

	  cb1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));


	//buttons	
  Add_To_Cart = new JButton( "Add To Cart" ); 

        Add_To_Cart .addMouseListener(new MouseAdapter()

        {

            public void mouseClicked(MouseEvent e)

            {

                    //System.out.println("noooooooooooooboni");
                    System.out.println(S);
              		try
						{
                           File file = new File(".\\File\\cart.txt");//
                            if (!file.exists())
							{
                                file.createNewFile();
                            }
                            FileWriter fw = new FileWriter(file, true);
                            BufferedWriter bw = new BufferedWriter(fw);
                            PrintWriter pw = new PrintWriter(bw);
							
							
                            pw.println("Storybook: Fundamentals of Physics");
							pw.println("quantity : " + result);
							pw.println("Taka:"+S);
                            pw.close();
							
							
										//////////////////////////////////////
									
                           File temp = new File(".\\File\\temp.txt");//
                            if (!temp.exists())
							{
                                temp.createNewFile();
                            }
                            FileWriter f = new FileWriter(temp, true);
                            BufferedWriter b = new BufferedWriter(f);
                            PrintWriter p = new PrintWriter(b);

							p.println("8");
                            p.close();
							
							
							

                        }
						catch (Exception ex)
						{
                            System.out.print(ex);
                        }


                     Cart c = new Cart();
					c.setVisible(false);
					  
                }
        }  );


	  Add_To_Cart.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	  Add_To_Cart.setForeground(Color.black);
	  Add_To_Cart.setBounds(670, 480, 150, 40);
	  Add_To_Cart.setBackground(new Color(212,175,55));
	  Add_To_Cart.setFont(f4);
	  Add_To_Cart.setFocusPainted(false);
	  frame.add(  Add_To_Cart);


     B = new JButton( "Buy Now" );// shorashori payment e jabe 
		 
		 B .addMouseListener(new MouseAdapter()

        {
			public void mouseClicked(MouseEvent e)

            {
  
                       new BuyNow();
					frame.setVisible(false);
					  
            }
        }  );

	    B.setForeground(Color.black);
	    B.setForeground(new Color(5, 102, 14));
        B.setBounds(390, 480, 150, 40);
		B.setBackground(new Color(212,175,55)); 
        B.setFont(f4);
        B.setFocusPainted(false);
        frame.add(B);
		
		
		

   

       Cart= new JButton(  );
		 Cart .addMouseListener(new MouseAdapter()

        {
			public void mouseClicked(MouseEvent e)

            {
                         new Cart();
					frame.setVisible(false);
					  
            }
        }  );
       
        Cart.setIcon(new ImageIcon("./photos/cart.png"));
		Cart.setBackground(new Color(255,255,255));
        Cart.setBounds(900,100,55,55);
		Cart.setFocusPainted(false);
        Cart.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        Cart.setContentAreaFilled(false);
		frame.add(Cart);
		


ImageIcon Main_image = new ImageIcon("./photos/text4.png");
Image For_Edith_image,Done_Image ;
For_Edith_image=Main_image.getImage();
Done_Image= For_Edith_image.getScaledInstance(250,400,Image.SCALE_SMOOTH);
Main_image=new ImageIcon (Done_Image);

JLabel Show_pic= new JLabel ("",Main_image,SwingConstants.LEFT);
Show_pic.setBounds(70,80,450,500);




        frame.add(Show_pic);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setResizable(false);
	
		
	}
	


public static void main (String []args)
{
 new Textbook4();
}

	
	
}