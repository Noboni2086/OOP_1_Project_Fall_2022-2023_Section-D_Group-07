package classes;
import java.lang.*;
import javax.swing .*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import java.io.*;



public class Sign_Up{



		JFrame Frame;
		JPanel p1,p2;
		JButton Cfirm;
		JLabel L_signup, L_First,L_Last, L_User, L_Email, L_phone,L_Password,L_conPass,L_ques,loging_j;
		JTextField T_First, T_last,T_User,T_Email,T_Phone ;
		JPasswordField P_pass,  P_Cnfpass; 
		String Num;// result er mdhe moboile number aaaaseeeee

		ImageIcon Main_image;  

		Image For_Edith_image,Done_Image ;                            //   
		String s;

		JLabel Show_pic;
			Timer tm;
			int x = 0;
			  
			String[] list =
				{   "./Photo/jaka.png",//0
					"./Photo/ride.png",//1
					"./Photo/online.png",//3
					"./Photo/map.png",//4		
					"./Photo/hp.png",//5
					
				};


		private  Cursor cursor;
		public Sign_Up ()
		{
		//fRAME DONE
		Frame = new JFrame ( );//"SIGN UP"




		Font f7 =new Font ( "Harlow Solid Italic",Font.PLAIN,24);
		JTextField tf4 = new JTextField("Fleur Book Shop");
		tf4.setBounds(550, 75, 220, 32);
		tf4.setFont(f7);
		tf4.setOpaque(true);
		s = tf4.getText();
		Frame.setTitle(s);




		Frame.setIconImage(Toolkit.getDefaultToolkit().getImage("Untitled.png"));
		Frame.setLayout(null);
		Frame.setSize(800,500);//(X,Y)
		Frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);




        Show_pic = new JLabel("",Main_image,SwingConstants.LEFT);
        Show_pic.setBounds(0, 0, 350, 500);// 985, 565

        //Function Call for SetImageSize
        SetImageSize(2);
         //timer
				tm = new Timer(3000,new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						SetImageSize(x);
						x += 1;
						if(x >= list.length )
							x = 0; 
					}
				});
			


		//font
		Font f1 =new Font ( "Harlow Solid Italic",Font.PLAIN,24);
		Font f2 =new Font ( "Freestyle Script",Font.BOLD,24);
		Font f3 =new Font ( "Times New Roman",Font.BOLD,14);



		//cursor
		cursor=new Cursor (Cursor.HAND_CURSOR);




		///////PANNEL
		p1 = new JPanel();
		p2 = new JPanel();



		//color of panel
		p1.setBackground(Color.gray);
		p2.setBackground(new Color(134,134,132,255));
		//setBounds of panel
		p1.setBounds(350,430,450,31);
		p2.setBounds(350,0,450,450);//350,0,450,450



		//pannel visibility
		p1.setVisible(true);
		p2.setVisible(true);



		///panel layout
		p1.setLayout( null);
		p2.setLayout( null);



		//panel add intu frame
		Frame.add(p1);
		Frame.add(p2);





		/////////////////////// labale
		L_signup = new JLabel(" Signup");
		L_signup.setBounds(160,0,90,48);
		L_signup.setForeground(new Color(0,0,0));
		L_signup.setFont(f1);
		L_signup.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 0)));
		p2.add(L_signup);




		L_First= new JLabel("First Name :");
		L_First.setForeground(Color.black);
		L_First.setBounds(50, 80, 120, 30);
		p2.add(L_First);




		L_Last = new JLabel("Last Name :");
		L_Last.setForeground(Color.black);
		L_Last.setBounds(50, 110, 120, 55);//
		p2.add(L_Last);




		L_User = new JLabel("User Name :");
		L_User.setForeground(Color.black);
		L_User.setBounds(50, 165, 120, 30);//
		p2.add(L_User);




		L_Email = new JLabel("Email:");
		L_Email.setForeground(Color.black);
		L_Email.setBounds(50,200, 120, 40);//
		p2.add(L_Email);




		L_phone = new JLabel("phone number:");
		L_phone.setForeground(Color.black);
		L_phone.setBounds(50, 240, 120, 40);//
		p2.add(L_phone);




		L_Password = new JLabel("Password:");
		L_Password.setForeground(Color.black);
		L_Password.setBounds(50, 285, 120, 40);//
		p2.add(L_Password);





		L_conPass = new JLabel("Confirm Password:");
		L_conPass.setForeground(Color.black);
		L_conPass.setBounds(50,325, 120, 40);//
		p2.add(L_conPass);




		//////field



		T_First = new JTextField();// signup border
		T_First.setBounds(170,77, 200, 25);
		T_First.setForeground(Color.BLACK);
		T_First.setOpaque(false);
		T_First.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 0)));
		p2.add(T_First);





		T_last = new JTextField();
		T_last.setBounds(170, 122, 200, 20);
		T_last.setForeground(Color.BLACK);
		T_last.setOpaque(false);
		T_last.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 5, 0)));
		p2.add(T_last);





		T_User = new JTextField();
		T_User.setBounds(170, 165, 200, 20);
		T_User.setForeground(Color.BLACK);
		T_User.setOpaque(false);
		T_User.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 0)));
		p2.add(T_User);



		T_Email = new JTextField();
		T_Email.setBounds(170, 207, 200, 20);
		T_Email.setForeground(Color.BLACK);
		T_Email.setOpaque(false);
		T_Email.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 0)));
		p2.add(T_Email);





		T_Phone = new JTextField();
		T_Phone.setBounds(170, 248, 200, 20);
		T_Phone.setForeground(Color.BLACK);
		T_Phone.setOpaque(false);
		T_Phone.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 0)));
		p2.add(T_Phone);




		P_pass = new JPasswordField();
		P_pass.setBounds(170, 290, 200, 20);
		P_pass.setFont(new Font("Arial", Font.PLAIN, 11));
		P_pass.setForeground(Color.BLACK);
		P_pass.setOpaque(false);
		P_pass.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 0)));
		p2.add(P_pass);




		P_Cnfpass = new JPasswordField();
		P_Cnfpass.setBounds(170, 330, 200, 20);
		P_Cnfpass.setFont(new Font("Arial", Font.PLAIN, 11));
		P_Cnfpass.setForeground(Color.BLACK);
		P_Cnfpass.setOpaque(false);
		P_Cnfpass.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 0)));
		p2.add(P_Cnfpass);





  ImageIcon open = new ImageIcon("./photos/open.png");
	ImageIcon close = new ImageIcon("./photos/close.png");
	
	
	JToggleButton showpass = new JToggleButton(close);
		showpass.setBounds(380, 290, 24, 24);
		showpass.setBackground(new Color(0,0,0));
		showpass.setForeground(new Color(0,0,0));
		showpass.setOpaque(false);
		showpass.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
		showpass.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				//String pword = pass.getText();
				if(showpass.isSelected())
				{
					showpass.setIcon(open);
					P_pass.setEchoChar((char)0);
				}
				
				else
				{
					showpass.setIcon(close);
					P_pass.setEchoChar('*');
				}
			}
		});
		showpass.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		p2.add(showpass);
		
		
		
		
		JToggleButton showpass2 = new JToggleButton(close);
		showpass2.setBounds(380, 330, 24, 24);
		showpass2.setBackground(new Color(0,0,0));
		showpass2.setForeground(new Color(0,0,0));
		showpass2.setOpaque(false);
		showpass2.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
		showpass2.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				//String pword = pass.getText();
				if(showpass2.isSelected())
				{
					showpass2.setIcon(open);
					P_Cnfpass.setEchoChar((char)0);
				}
				
				else
				{
					showpass2.setIcon(close);
					P_Cnfpass.setEchoChar('*');
				}
			}
		});
		showpass2.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		p2.add(showpass2);



//////////comfirm Button
  
//button e action hbe 
 Cfirm=new JButton("Confirm");



 



      Cfirm .addMouseListener(new MouseAdapter()

        {

            //Override

            public void mouseClicked(MouseEvent e)

            {
				String s_First = T_First.getText(); // First Name
                String s_Last = T_last.getText(); // Last Name
                String s_User = T_User.getText(); // User Name
                String s_Email = T_Email.getText(); // Email
                String s_Phone = T_Phone.getText(); // Mobile
                String s_pass = P_pass.getText(); // Password
                String s_Cnfpass = P_Cnfpass.getText(); // Confirmpass


                 
				  if ( s_First.isEmpty() || s_Last.isEmpty() || s_User.isEmpty() || s_Email.isEmpty()
                            || s_pass.isEmpty()||s_Cnfpass.isEmpty())
                    {
                        JOptionPane.showMessageDialog(null, "Please fill all of the fields.", "Warning!", JOptionPane.WARNING_MESSAGE);
                    }  
				  
				 else{
					 
					        if (s_Phone.length()<11)
				            {
                              JOptionPane.showMessageDialog(null, "Enter 11 digit phone number", "Warning!", JOptionPane.WARNING_MESSAGE);
					
                            }
                         
                   
					      else  if (s_Phone.length()==11)
				            {
                              Num = T_Phone.getText();
					
                            }
                         
                     
					        if (s_pass.equals(s_Cnfpass)==false)
                            {                    
                            JOptionPane.showMessageDialog(null, "Password doesnot match", "Warning!", JOptionPane.WARNING_MESSAGE);
				            }
				  
					  else
					   {
                        try
						{
                            File file = new File(".\\Udata\\user_data.txt");//
                            if (!file.exists())
							{
                                file.createNewFile();
                            }
                            FileWriter fw = new FileWriter(file, true);
                            BufferedWriter bw = new BufferedWriter(fw);
							
							
                            PrintWriter pw = new PrintWriter(bw);
							
                            pw.println("First Name : " + s_First);  
							pw.println("Last Name: " + s_Last);
							pw.println("User Name: " + s_User);
							pw.println("Email : " + s_Email);
                            pw.println("Mobile No: " + Num);
							pw.println("password : " + s_pass);
                            pw.close();
							//System.out.println("hi");
							new GetStarted();
                        Frame.setVisible(false);
						 //   JOptionPane.showMessageDialog(null, "Welcome",  "Flure Book Shop", JOptionPane.WARNING_MESSAGE);
                        }

                     
						catch (Exception ex)
						{
                            System.out.print(ex);
                        }

                
			        }
				 }
			}	 
			});

		Cfirm.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

				Cfirm .setFont(f3);
			//  Cfirm.setForeground(new Color(62,63,44,255));//62,63,44,255
				Cfirm. setBackground(new Color(62,63,44,255));
				Cfirm.setForeground(Color.WHITE);
				Cfirm.setBounds(170, 380, 95, 20);
				p2.add(Cfirm);

		//Cfirm.setOpaque(false);




		///jlable Login
		L_ques = new JLabel("Alrerady have an account?");
		L_ques.setBounds(110, 400, 165, 40);//115, 390, 300, 40  110, 390, 150, 10   ////// 400   2
		L_ques.setFont(f3);
		L_ques.setForeground(new Color(0,0,0));
		p2.add(L_ques);






			  loging_j = new JLabel("Login");
			   loging_j .addMouseListener(new MouseAdapter()
				{
					//Override
					public void mouseClicked(MouseEvent e)
					{
					   new GetStarted();
					   // l.setVisible(true);
					   Frame.setVisible(false);
					}
				});
				loging_j .setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
				loging_j .setFont(f3);
				loging_j .setForeground(new Color(135,206,235));
				loging_j .setBounds(280, 400, 50, 40);
				p2.add(loging_j ); 
				





		Frame.setLocationRelativeTo(null);
		Frame.setVisible(true);

		 Frame.add(Show_pic);
				tm.start();
		 




		}



		  //image resize
			public void SetImageSize(int i)
			{
				ImageIcon Main_image = new ImageIcon(list[i]);//Main_image
				Image For_Edith_image = Main_image.getImage();//For_Edith_image=Main_image
				Image Done_Image = For_Edith_image.getScaledInstance(350,500,Image.SCALE_SMOOTH);//Done_Image=For_Edith_image
				Main_image = new ImageIcon(Done_Image);
				
				// pic = new JLabel("",Main_image,SwingConstants.LEFT);
			  Show_pic.setIcon(Main_image);
			}


		public static void main (String []args)
		{
		 new Sign_Up();





		}




		}