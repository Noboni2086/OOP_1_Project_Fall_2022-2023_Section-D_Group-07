package classes;
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.Font;
import java.awt.event.*;
import java.awt.Color;
import java.util.*;
import java.awt.Cursor;
import javax.swing.border.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import static javax.swing.JOptionPane.showMessageDialog;

public class Cart extends JFrame {
	
  JLabel J_Flure,J_favourite, Online,Name,Adress,Gmail,Delivery,Total_Taka,Pay,Show_pic; 
  JTextField T_Name,T_add,T_Gmail,T_Pay;
  JButton Confirm ;
  double ans;
  double value=0;
	 String k;
	  int t = 0;
	    String no ="1";
	    String bo ="2";  
		String ni ="3";
		  String sh ="4";
		    String ra ="5";
			  String ko ="6";
			    String lo ="7";
				  String so ="8";
	// cons
	
	public Cart( ){
////Frame		
    setLayout(null);
    setSize(1100, 700);
		
	//Font	
	Font f1 =new Font ( "Freestyle Script",Font.BOLD,50);
    Font f2 =new Font ( "Harlow Solid Italic",Font.PLAIN,24);
    Font f3 =new Font ( "Times New Roman",Font.BOLD,30);
    Font f4 =new Font ( "Times New Roman",Font.PLAIN,20);
	
	
	
	
	//JLabel	
	J_Flure = new JLabel( "Fleur Bookshop");
	    J_Flure.setForeground(new Color(212,175,55));
        J_Flure.setBounds(700, 0, 800, 80);
        J_Flure.setFont(f1);
        add(J_Flure);


    J_favourite = new JLabel( "get your favourite books right now!");
	    J_favourite.setForeground(new Color(0,5,0));
        J_favourite.setBounds(655, 30, 750, 80);
        J_favourite.setFont(f2);
        add(J_favourite);
		
    Online = new JLabel( "Cash On Delivery");
	    Online.setForeground(new Color(0,5,0));
        Online.setBounds(700,90, 750, 80);
        Online.setFont(f3);
        add(Online);
 

		
    Name = new JLabel( "Name    :");
	    Name.setForeground(new Color(0,5,0));
        Name.setBounds(545, 160, 750, 80);
        Name.setFont(f4);
        add(Name);


    Adress = new JLabel( "Address :");
	    Adress.setForeground(new Color(0,5,0));
        Adress.setBounds(545, 210, 750, 80);
        Adress.setFont(f4);
        add(Adress);
		
		
    Gmail = new JLabel( "Gmail    :" );
	    Gmail.setForeground(new Color(0,5,0));
        Gmail.setBounds(545, 260, 750, 80);
        Gmail.setFont(f4);
        add(Gmail);
		
		
		
		
			
    Delivery = new JLabel( "Delivery charge free!! " );
		Delivery.setFont(f4);
	    Delivery.setForeground(new Color(255, 0, 0));
        Delivery.setBounds(545,330, 750, 80);
		add(Delivery);

		
		
		
		
    Total_Taka = new JLabel( "Total Taka :" );
		Total_Taka.setForeground(new Color(5, 102, 8));
	    Total_Taka.setFont(f4);
        Total_Taka.setBounds(545, 360, 750, 80);
		add(Total_Taka);
		
		
		
		
		
    Pay = new JLabel( "Pay     :" );
		Pay.setFont(f4);
	    Pay.setForeground(new Color(0,5,0));
        Pay.setBounds(545, 400, 750, 80);
		add(Pay);
		
		
		

	///textField
				
   T_Name = new JTextField();
     T_Name.setBounds(630,180, 390, 30);
     T_Name.setForeground(Color.BLACK);
     T_Name.setOpaque(false);
     T_Name.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 0)));
     add(T_Name);
	
		
		
   T_add = new JTextField();
      T_add.setBounds(630,230, 390, 30);
      T_add.setForeground(Color.BLACK);
      T_add.setOpaque(false);
      T_add.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 0)));
      add(T_add);


		
  T_Gmail= new JTextField();
     T_Gmail.setBounds(630,280, 390, 30);
     T_Gmail.setForeground(Color.BLACK);
     T_Gmail.setOpaque(false);
     T_Gmail.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 0)));
     add(T_Gmail);
		
		

			
   T_Pay = new JTextField();
    T_Pay.setBounds(630,420, 390, 30);
    T_Pay.setForeground(Color.BLACK);
    T_Pay.setOpaque(false);
    T_Pay.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 0)));
    add(T_Pay);


//////////file read and value update
		
                  try
					 {
						FileReader fr = new FileReader(".\\File\\cart.txt");
                        BufferedReader reader = new BufferedReader(fr);
                        String line;
		                String lineuser;
		                int totalLines = 0;
                        while ((line=reader.readLine()) != null)
				        {
					     totalLines++;
				        }
				        reader.close();
                       
			            int cal=0;
                        String money =null ;
                        for (int i = 0; i <= totalLines; i++)
							 
						{   cal=cal+2;
                            lineuser = Files.readAllLines(Paths.get(".\\File\\cart.txt")).get(i+cal);
						    money=lineuser.substring (5,10);
							ans=Double.parseDouble(money);
							value = value+ans;
							 
						}
							  
					 }

				catch (Exception ex)
					{
                        System.out.println(ex);
                    }
					
					
	//double turn into String for jlable 				
        String S = String.valueOf(value);

	    JLabel Quantity = new JLabel(S);
	    Quantity.setFont(f4);
    	Quantity.setForeground(new Color(5, 102, 8));	
        Quantity.setBounds(660, 360, 750, 80);
        add(Quantity);
	  
	  
	////button  
	Confirm = new JButton( "Confirm" );// shorashori payment e jabe 
	
       Confirm .addMouseListener(new MouseAdapter()

        {
		public void mouseClicked(MouseEvent e)

            {
				

                   String s_First = T_Pay.getText(); 	   
                   String s_Second = T_Name.getText(); 
                   String s_Third = T_add.getText(); 
                   String s_Forth = T_Gmail.getText(); 

				  if ( s_First.isEmpty()|| s_Second.isEmpty()||s_Third.isEmpty()||s_Forth.isEmpty() )
                       {
                        JOptionPane.showMessageDialog(null, "Please fill up all the fildes", "Warning!", JOptionPane.WARNING_MESSAGE);
                       }  
				   
                  else
				  {
                          
                     
					     if (s_First.equals(S)==false)
                         {                    
                            JOptionPane.showMessageDialog(null, "Please pay exact amount", "Warning!", JOptionPane.WARNING_MESSAGE);
				          }
				  
					  else
					   {
                        

                        JOptionPane.showMessageDialog(null, "Thanks for Shoping ",  "Flure book shope", JOptionPane.WARNING_MESSAGE);
                        

                            File file = new File(".\\File\\cart.txt");//
							boolean success =file.delete();
							System.out.println(success);
                       }
                  }
				
			}
		});
	    Confirm.setForeground(Color.black);
	    Confirm.setForeground(new Color(5, 102, 14));
        Confirm.setBounds(730, 540, 150, 40);
		Confirm.setBackground(new Color(212,175,55)); 
        Confirm.setFont(f4);
        Confirm.setFocusPainted(false);
        add(Confirm);
		
		
	 

/// image
ImageIcon Main_image = new ImageIcon("./photos/Payment.png");
Image For_Edith_image,Done_Image ;
For_Edith_image=Main_image.getImage();
Done_Image= For_Edith_image.getScaledInstance(500,700,Image.SCALE_SMOOTH);
Main_image=new ImageIcon (Done_Image);

 Show_pic= new JLabel ("",Main_image,SwingConstants.LEFT);
Show_pic.setBounds(0,0,600,700);
 add(Show_pic);
 File temp = new File(".\\File\\temp.txt");
	  
		try{
		
		                
				        FileReader f = new FileReader(".\\File\\temp.txt");
                        BufferedReader b = new BufferedReader(f);
                        String ln;
		               
		               
                        while ((ln=b.readLine()) != null)
				        {
					     t++;
				        }
				        b.close();
						  for (int i = 0; i <=t; i++)
							 
						{  
						k = Files.readAllLines(Paths.get(".\\File\\temp.txt")).get(i);}
		
		
		    }
		
			
		                     catch (Exception ex )
	                    	{
			                      System.out.println(ex);
		                    }
		
		JButton  back =new JButton();
		
		
		back = new JButton();
		
		back.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{ 

                      if (temp.exists()){
						  
						  
						try{  
                      
                       
			            
                      ////////////////////storybooks
						   if (k.equals(sh))
						   {
							   new Storybook4();
        	                    setVisible(false);
				            System.out.println("hi");
							
						    File te = new File(".\\File\\temp.txt");//
							boolean suc =te.delete();
							System.out.println(suc);
							
						   }
						   
						 else  if (k.equals(ni))
						   {
							   new Storybook3();
        	                    setVisible(false);
				            System.out.println("hi");
							
							  File te = new File(".\\File\\temp.txt");//
							boolean suc =te.delete();
							System.out.println(suc);
							
						   }
						   
						   
						    else  if (k.equals(bo))
						   {
							   new Storybook2();
        	                setVisible(false);
				            System.out.println("hi");
							
							  File te = new File(".\\File\\temp.txt");//
							boolean suc =te.delete();
							System.out.println(suc);
							
						   }
						   
						   else  if (k.equals(no))
						   {
							   new Storybook1();
        	                    setVisible(false);
				            System.out.println("hi");
							
							  File te = new File(".\\File\\temp.txt");//
							boolean suc =te.delete();
							System.out.println(suc);
							
						   } 
						   
						   
						   
						         ////////////////////Textbooks
						   
						   
						   
						     else  if (k.equals(ra))
						   {
							  new Textbook1();
        	                    setVisible(false);
				            System.out.println("hi");
							
							  File te = new File(".\\File\\temp.txt");//
							boolean suc =te.delete();
							System.out.println(suc);
							
						   } 
						   
						   
						   
						   
						   
						     else  if (k.equals(ko))
						   {
							   new Textbook2();
        	                    setVisible(false);
				            System.out.println("hi");
							
							  File te = new File(".\\File\\temp.txt");//
							boolean suc =te.delete();
							System.out.println(suc);
							
						   } 
						   
						   
						   
						     else  if (k.equals(lo))
						   {
							  new Textbook3();
        	                    setVisible(false);
				            System.out.println("hi");
							
							  File te = new File(".\\File\\temp.txt");//
							boolean suc =te.delete();
							System.out.println(suc);
							
						   } 
						   
						   
						     else  if (k.equals(so))
						   {
							    new Textbook4();
        	                    setVisible(false);
				            System.out.println("hi");
							
							  File te = new File(".\\File\\temp.txt");//
							boolean suc =te.delete();
							System.out.println(suc);
							
						   } 
						   
						   

						   
							 
						}
						
						
						
						catch (Exception ex){
							System.out.println(ex);
						}
						
						
					  }
						
						else{
							      new  UserDashboard ();
								  setVisible(false);
						}
							
			
			}
		});
		back.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
        back.setIcon(new ImageIcon("./photos/back.png"));
		back.setBackground(new Color(255,255,255));
        back.setBounds(10, 2, 25, 25);
        back.setFocusPainted(false);
		Show_pic.add(back);
		
	  
	  
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setLocationRelativeTo(null);
      setVisible(true);
      setResizable(false);
		
			}
			
			
public static void main (String []args)
{
 new Cart();


}

	
			
	}
		
	