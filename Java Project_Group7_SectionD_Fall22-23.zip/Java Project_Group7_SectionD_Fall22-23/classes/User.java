package classes;
import java.lang.*;
public abstract class User {
   
     private String abname;
	 private String abpass;
	
	public User(String abname, String abpass)
	{
		this.abname = abname;
		this.abpass = abpass;
	}
	
	public String getAbName()
	{
		return abname;
	}
	public String getAbPass()
	{
		return abpass;
	}
    
}
