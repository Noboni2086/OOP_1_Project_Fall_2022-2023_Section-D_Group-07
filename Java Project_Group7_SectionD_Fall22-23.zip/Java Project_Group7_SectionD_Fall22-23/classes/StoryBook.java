package classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import static javax.swing.JOptionPane.showMessageDialog;

public class StoryBook
{
	JFrame frame;
	JPanel backpanel;
	JPanel intropanel;
	JButton userB;
	JLabel user;
	JButton exitB;
	JButton minB;
	JButton backB;
	JLabel intro, story;
	JButton storyB1, storyB2, storyB3, storyB4, storyB5, storyB6, storyB7, storyB8;
	//JLabel name1, isbn1, author1, price1, name2, isbn2, author2, price2, name3, isbn3, author3, price3, name4, isbn4, author4, price4, name5, isbn5, author5, price5, 
	JLabel name1, price1;
	JLabel name2, price2;
	JLabel name3, price3;
	JLabel name4, price4;
	JLabel name5, price5;
	JLabel name6, price6;
	JLabel name7, price7;
	JLabel name8, price8;
	
	public StoryBook()
	{
		frame = new JFrame();
	    frame.setLayout(null);
		
	    frame.setSize(1300,700);
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//font
		Font f1 = new Font("Harlow Solid Italic", Font.PLAIN, 20);
		Font f2 = new Font("Freestyle Script", Font.BOLD, 38);
		Font f3 = new Font("Times New Roman", Font.BOLD, 24);
		Font f4 = new Font("Times New Roman", Font.PLAIN, 18);
		Font f5 = new Font("Times New Roman", Font.PLAIN, 14);
		Font f6 = new Font("Harlow Solid Italic", Font.PLAIN, 30);
		
		//background panel
		backpanel = new JPanel();
	    backpanel.setBackground(new Color(192,192,192));
	    backpanel.setBounds(0,0,1300,700);
	    backpanel.setVisible(true);
	    backpanel.setLayout(null);
		frame.add(backpanel);
		
		//intro panel
		intropanel = new JPanel();
	    intropanel.setBackground(new Color(255,255,255));
	    intropanel.setBounds(0,0,1300,100);
	    intropanel.setVisible(true);
	    intropanel.setLayout(null);
		backpanel.add(intropanel);
		
		
		/*//accountbutton
		userB = new JButton();
        userB.setIcon(new ImageIcon("account.png"));
		userB.setBackground(new Color(255,255,255));
        userB.setBounds(1100,20,55,55);
		userB.setFocusPainted(false);
        userB.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        userB.setContentAreaFilled(false);
		intropanel.add(userB);
		
		//username
		user = new JLabel("user");
		user.setForeground(Color.BLACK);
		user.setBounds(1115, 77, 55, 16);
		user.setFont(f5);
		intropanel.add(user);*/
		
		//exit button
		exitB = new JButton();
		
		exitB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				  frame.setVisible(false);
			}
		});
		exitB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		exitB.setIcon(new ImageIcon("./photos/exit.png"));
		exitB.setBackground(new Color(255,255,255));
        exitB.setBounds(1230, 2, 25, 25);
        exitB.setFocusPainted(false);
        exitB.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        exitB.setContentAreaFilled(false);
		intropanel.add(exitB);

        //minimize button
        minB = new JButton();
		
		minB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				   frame.setState(Frame.ICONIFIED);
			}
		});
		minB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		minB.setIcon(new ImageIcon("./photos/min.png"));
		minB.setBackground(new Color(0,0,0));
        minB.setBounds(1190, 2, 24, 24);
        minB.setFocusPainted(false);
        minB.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        minB.setContentAreaFilled(false);
		intropanel.add(minB);
		
		//back button
		backB = new JButton();
		
		backB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				new UserDashboard();
        		frame.setVisible(false);
			}
		});
		backB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
        backB.setIcon(new ImageIcon("./photos/back.png"));
		backB.setBackground(new Color(255,255,255));
        backB.setBounds(10, 2, 25, 25);
        backB.setFocusPainted(false);
        backB.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        backB.setContentAreaFilled(false);
		intropanel.add(backB);
		
		
		//title labels
		intro = new JLabel("FLEUR online Bookshop");
		intro.setForeground(new Color(212,175,55));
		intro.setBounds(510, 20, 400, 30);
		intro.setFont(f2);
		intropanel.add(intro);
		
		//intro labels
		intro = new JLabel("Get your favourite books right now!");
		intro.setForeground(Color.BLACK);
		intro.setBounds(500, 55, 400, 30);
		intro.setFont(f1);
		intropanel.add(intro);
		
		//category
		story = new JLabel("storybooks");
		story.setForeground(new Color(0,0,0));
		story.setBounds(570, 110, 170, 40);
		story.setFont(f6);
		backpanel.add(story);
		
		
		////////////////////////////////////////////////////////////
		//storybook1
		storyB1 = new JButton();
        storyB1.setIcon(new ImageIcon("./photos/storybook1.png"));
        storyB1.setBounds(130,180,100,150);
		storyB1.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				new Storybook1();
        		frame.setVisible(false);
			}
		});
		storyB1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backpanel.add(storyB1);
		
		name1 = new JLabel("Harry Potter & the Prisoner of Azkaban");
		name1.setForeground(new Color(0,0,0));
		name1.setBounds(70, 330, 220, 14);
		name1.setFont(f5);
		backpanel.add(name1);
		
		price1 = new JLabel("1060 tk");
		price1.setForeground(new Color(0,0,0));
		price1.setBounds(155, 345, 220, 14);
		price1.setFont(f5);
		backpanel.add(price1);
		
		
		////////////////////////////////////////////////////////
		//storybook2
		storyB2 = new JButton();
        storyB2.setIcon(new ImageIcon("./photos/storybook2.png"));
        storyB2.setBounds(430,180,100,150);
		storyB2.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				new Storybook2();
        		frame.setVisible(false);
			}
		});
		storyB2.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backpanel.add(storyB2);
		
		name2 = new JLabel("The Hobbit");
		name2.setForeground(new Color(0,0,0));
		name2.setBounds(445, 330, 220, 14);
		name2.setFont(f5);
		backpanel.add(name2);
		
		price2 = new JLabel("1270 tk");
		price2.setForeground(new Color(0,0,0));
		price2.setBounds(455, 345, 220, 14);
		price2.setFont(f5);
		backpanel.add(price2);
		
		
		
		
		////////////////////////////////////////////////////////
		//storybook3
		storyB3 = new JButton();
        storyB3.setIcon(new ImageIcon("./photos/storybook3.png"));
        storyB3.setBounds(730,180,95,150);
		storyB3.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				new Storybook3();
        		frame.setVisible(false);
			}
		});
		storyB3.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backpanel.add(storyB3);
		
		name3 = new JLabel("A Study in Scarlet");
		name3.setForeground(new Color(0,0,0));
		name3.setBounds(730, 330, 220, 14);
		name3.setFont(f5);
		backpanel.add(name3);
		
		price3 = new JLabel("500 tk");
		price3.setForeground(new Color(0,0,0));
		price3.setBounds(760, 345, 220, 14);
		price3.setFont(f5);
		backpanel.add(price3);
		

		////////////////////////////////////////////////////////
		//storybook4
		storyB4 = new JButton();
        storyB4.setIcon(new ImageIcon("./photos/storybook4.png"));
        storyB4.setBounds(1030,180,100,150);
		storyB4.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				new Storybook4();
        		frame.setVisible(false);
			}
		});
		storyB4.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backpanel.add(storyB4);
		
		name4 = new JLabel("The Haunting of Hill House");
		name4.setForeground(new Color(0,0,0));
		name4.setBounds(1000, 330, 220, 16);
		name4.setFont(f5);
		backpanel.add(name4);
		
		price4 = new JLabel("600 tk");
		price4.setForeground(new Color(0,0,0));
		price4.setBounds(1063, 345, 220, 14);
		price4.setFont(f5);
		backpanel.add(price4);
		
		
		
		///////////////////////////////////////////
		//storybook5
		storyB5 = new JButton();
        storyB5.setIcon(new ImageIcon("./photos/storybook5.png"));
        storyB5.setBounds(130,405,100,150);
		storyB5.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				showMessageDialog(null, "Not available","Warning", JOptionPane.WARNING_MESSAGE);
			}
		});
		storyB5.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backpanel.add(storyB5);
		
		name5 = new JLabel("Harry Potter & the Half-Blood Prince");
		name5.setForeground(new Color(0,0,0));
		name5.setBounds(70, 555, 220, 14);
		name5.setFont(f5);
		backpanel.add(name5);
		
		price5 = new JLabel("1020 tk");
		price5.setForeground(new Color(0,0,0));
		price5.setBounds(155, 570, 220, 14);
		price5.setFont(f5);
		backpanel.add(price5);
		
		////////////////////////////////////////////////
		//storybook6
		storyB6 = new JButton();
        storyB6.setIcon(new ImageIcon("./photos/storybook6.png"));
        storyB6.setBounds(430,405,100,149);
		storyB6.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				showMessageDialog(null, "Not available","Warning", JOptionPane.WARNING_MESSAGE);
			}
		});
		storyB6.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backpanel.add(storyB6);
		
		name6 = new JLabel("The Lord of the Rings");
		name6.setForeground(new Color(0,0,0));
		name6.setBounds(417, 555, 220, 15);
		name6.setFont(f5);
		backpanel.add(name6);
		
		price6 = new JLabel("1270 tk");
		price6.setForeground(new Color(0,0,0));
		price6.setBounds(458, 570, 220, 14);
		price6.setFont(f5);
		backpanel.add(price6);
		
		
		//storybook7
		storyB7 = new JButton();
        storyB7.setIcon(new ImageIcon("./photos/storybook7.png"));
        storyB7.setBounds(735,405,85,150);
		storyB7.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				showMessageDialog(null, "Not available","Warning", JOptionPane.WARNING_MESSAGE);
			}
		});
		storyB7.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backpanel.add(storyB7);
		
		name7 = new JLabel("Dune");
		name7.setForeground(new Color(0,0,0));
		name7.setBounds(765, 555, 220, 14);
		name7.setFont(f5);
		backpanel.add(name7);
		
		price7 = new JLabel("800 tk");
		price7.setForeground(new Color(0,0,0));
		price7.setBounds(762, 570, 220, 14);
		price7.setFont(f5);
		backpanel.add(price7);
		
		
		
		//////////////////////////////////////////////////////
		//storybook8
		storyB8 = new JButton();
        storyB8.setIcon(new ImageIcon("./photos/storybook8.png"));
        storyB8.setBounds(1030,405,100,148);
		storyB8.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				showMessageDialog(null, "Not available","Warning", JOptionPane.WARNING_MESSAGE);
			}
		});
		storyB8.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backpanel.add(storyB8);
		
		name8 = new JLabel("A Wrinkle in Time");
		name8.setForeground(new Color(0,0,0));
		name8.setBounds(1030, 555, 220, 16);
		name8.setFont(f5);
		backpanel.add(name8);
		
		price8 = new JLabel("720 tk");
		price8.setForeground(new Color(0,0,0));
		price8.setBounds(1063, 570, 220, 14);
		price8.setFont(f5);
		backpanel.add(price8);
		
		
		
		frame.setVisible(true);
        frame.setLocationRelativeTo(null);
		frame.setResizable(false);
	}
	
	
	
	
	
	//main method
	public static void main (String [] args )
	{
		
		new StoryBook();	
	}	
}