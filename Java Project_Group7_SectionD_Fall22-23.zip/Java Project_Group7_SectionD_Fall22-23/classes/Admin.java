package classes;
import java.lang.*;
import javax.swing.*;
import java.awt.event.*; 
import javax.swing.border.MatteBorder;
import java.awt.*;

import static javax.swing.JOptionPane.showMessageDialog;
import java.awt.Font; 
public class Admin implements ActionListener {
    
        JLabel  intro,name, pass;
		JPanel panel;
        JFrame frame;
        JTextField username;
        JPasswordField password;
        JButton loginbtn;
        JButton exitbtn;
        Font f;
        AdminUser u1,u2,u3,u4;
        AdminUser users[];
		JButton backB;

    
       
    Admin(){



        u1 = new AdminUser("Mazid", "1234");
		u2 = new AdminUser("Rakib", "1111");
        u3 = new AdminUser("Noboni","2222");
        u4 = new AdminUser("Shushmita","3333");
		users = new AdminUser[4];
		users[0] = u1;
		users[1] = u2;
        users[2] = u3;
        users[3] = u4;
   
        //JFrame frame = new JFrame();
       
        frame = new JFrame("Admin page");


        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setSize(500, 400);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        //frame.setTitle("Admin Page");
        frame.getContentPane().setBackground(Color.gray);
		
		Font f1 = new Font("Harlow Solid Italic", Font.PLAIN, 20);
		Font f2 = new Font("Freestyle Script", Font.BOLD, 38);
		
		panel = new JPanel();
	    panel.setBackground(new Color(255,255,255));
	    panel.setBounds(0,0,500,100);
	    panel.setVisible(true);
	    panel.setLayout(null);
		frame.add(panel);
		
		//title labels
		intro = new JLabel("FLEUR online Bookshop");
		intro.setForeground(new Color(212,175,55));
		intro.setBounds(110, 20, 400, 30);
		intro.setFont(f2);
		panel.add(intro);
		
		//intro labels
		intro = new JLabel("Get your favourite books right now!");
		intro.setForeground(Color.BLACK);
		intro.setBounds(100, 60, 400, 30);
		intro.setFont(f1);
		panel.add(intro);
		
		backB = new JButton();
		
		backB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				new GetStarted();
        		frame.setVisible(false);
			}
		});
		backB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backB.setIcon(new ImageIcon("./photos/back.png"));
		backB.setBackground(new Color(255,255,255));
        backB.setBounds(10, 2, 25, 25);
        backB.setFocusPainted(false);
        backB.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        backB.setContentAreaFilled(false);
	    panel.add(backB);



        f = new Font("Arial",Font.ITALIC,16);
        name = new JLabel("Username :");
        pass = new JLabel("Password :");
        username = new JTextField();
        password = new JPasswordField();
        loginbtn = new JButton("Login");
        exitbtn = new JButton("Exit");
        name.setFont(f);
        pass.setFont(f);
        username.setFont(f);



        name.setBounds(50, 120, 120, 50);
        pass.setBounds(50, 180, 120, 50);
        password.setBounds(50, 160, 120, 50);
        password.setOpaque(false);
        password.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 0)));
        username.setBounds(180, 125, 250, 30);
        username.setOpaque(false);
        username.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 0)));
        password.setBounds(180, 185, 250, 30);
        loginbtn.setBounds(180, 270, 100, 30);
        exitbtn.setBounds(320, 270, 100, 30);


        frame.add(name);
        frame.add(pass);
        frame.add(username);
        frame.add(password);
        loginbtn.addActionListener(this);
        exitbtn.addActionListener(this);
        frame.add(loginbtn);
        frame.add(exitbtn);
        
        
       frame.setVisible(true);


   }
    
    
        public void actionPerformed(ActionEvent e) {  
         
            if(e.getSource()==loginbtn)
            {  
                String user = username.getText();
                String pass = password.getText();
                
                int flag = 0;
                
                if(user.isEmpty()==false && pass.isEmpty()==false)
                {
                    for(int i = 0; i<users.length; i++)
                    {
                        if(users[i]!=null)
                        {
                            if(user.equals(users[i].getAbName()) && pass.equals(users[i].getAbPass()))
                            {
                                flag = 1;
                                break;
                                
                            }
                        }
                    }
                    if (flag == 1)
                    {
                        new AdminDashboard();
                        
                        frame.setVisible(false);
                    }
                    else
                    {
                        showMessageDialog(null, "Invalid Username or password!");
                    }
                }
                else
                {
                    showMessageDialog(null,"Fill up every field.");
                }
                
            }  
            else if(e.getSource()==exitbtn)
            {
                System.exit(0);
            }
        }  
        
public static void main (String [] args)
{
    
    
    new Admin ();
    
}
    
    
}